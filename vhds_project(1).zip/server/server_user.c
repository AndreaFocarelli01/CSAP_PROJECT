#define _POSIX_C_SOURCE 200809L
#define _XOPEN_SOURCE   700

#include "server.h"
#include "network.h"
#include "filesystem.h"

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

/*
 * server_user.c — Gestione utenti e sessioni VHDS
 *
 * Gli utenti VHDS sono SOLO virtuali: esistono nella SessionTable
 * in shared memory e nel filesystem VFS. Non viene creato alcun
 * utente di sistema reale, non serve sudo, non serve alcun
 * privilegio speciale.
 *
 * I permessi (uid/gid virtuali) vengono assegnati in modo
 * progressivo partendo da 1000 e sono usati SOLO dal server
 * per i controlli di accesso interni — non corrispondono a
 * nessun uid/gid del sistema operativo.
 */

/* ─────────────────────────────────────────────
 * next_virtual_uid
 * Scansiona la SessionTable e restituisce il
 * primo uid virtuale libero >= 1000.
 * ───────────────────────────────────────────── */
static uid_t next_virtual_uid(SessionTable *tbl) {
    uid_t max_uid = 999;
    for (int i = 0; i < MAX_USERS; i++) {
        if (tbl->users[i].valid && tbl->users[i].uid > max_uid)
            max_uid = tbl->users[i].uid;
    }
    return max_uid + 1;
}

/* ─────────────────────────────────────────────
 * cmd_create_user
 *
 * Crea un utente virtuale VHDS:
 * 1. Valida username e permessi.
 * 2. Verifica che non esista già.
 * 3. Crea la home directory nel VFS.
 * 4. Assegna uid/gid virtuali progressivi.
 * 5. Registra nella SessionTable.
 *
 * Non richiede privilegi di sistema, non chiama
 * adduser, non usa sudo.
 * ───────────────────────────────────────────── */
int cmd_create_user(int client_fd, const char *username,
                    const char *perm_str) {
    mode_t perm;
    if (parse_permissions(perm_str, &perm) < 0) {
        net_send_response(client_fd, RES_ERROR,
                          "ERROR: invalid permissions (use octal, e.g. 0755)");
        return -1;
    }

    /* Sanity check: solo lettere minuscole, cifre, '_', '-' */
    for (int i = 0; username[i]; i++) {
        char c = username[i];
        if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') ||
              c == '_' || c == '-')) {
            net_send_response(client_fd, RES_ERROR,
                              "ERROR: invalid username characters "
                              "(only lowercase letters, digits, _ -)");
            return -1;
        }
    }

    if (username[0] == '\0') {
        net_send_response(client_fd, RES_ERROR, "ERROR: empty username");
        return -1;
    }

    /* Controlla duplicati */
    if (session_find_user(G.sess_tbl, username) != NULL) {
        net_send_response(client_fd, RES_ERROR,
                          "ERROR: user already exists");
        return -1;
    }

    /* Assegna uid/gid virtuali */
    uid_t new_uid = next_virtual_uid(G.sess_tbl);
    gid_t new_gid = new_uid;   /* gid = uid per semplicità */

    /* Costruisci path home nel VFS: <vfs_root>/<username> */
    char home_path[MAX_PATH];
    int w = snprintf(home_path, sizeof(home_path),
                     "%s/%s", G.vfs_root, username);
    if (w < 0 || (size_t)w >= sizeof(home_path)) {
        net_send_response(client_fd, RES_ERROR, "ERROR: path too long");
        return -1;
    }

    /* Crea la directory home nel VFS */
    if (mkdir(home_path, perm) < 0 && errno != EEXIST) {
        char errmsg[256];
        snprintf(errmsg, sizeof(errmsg),
                 "ERROR: cannot create home directory: %s", strerror(errno));
        net_send_response(client_fd, RES_ERROR, errmsg);
        return -1;
    }

    /* Scrivi i metadati di proprietà virtuale sulla home.
     * Senza questo file .vhds_own, fs_check_permission negherebbe
     * l'accesso anche al proprietario stesso. */
    fs_set_owner(home_path, new_uid, new_gid);

    /* Registra nella SessionTable */
    if (session_add_user(G.sess_tbl, username, home_path,
                         perm, new_uid, new_gid) < 0) {
        net_send_response(client_fd, RES_ERROR,
                          "ERROR: cannot register user (table full?)");
        return -1;
    }

    char msg[MAX_USERNAME + 64];
    snprintf(msg, sizeof(msg), "OK User '%s' created (uid=%d)",
             username, (int)new_uid);
    net_send_response(client_fd, RES_OK, msg);
    log_info("Virtual user '%s' created (uid=%d gid=%d home=%s)",
             username, (int)new_uid, (int)new_gid, home_path);
    return 0;
}

/* ─────────────────────────────────────────────
 * cmd_login
 * ───────────────────────────────────────────── */
int cmd_login(int client_fd, const char *username,
              int *sess_idx_out, Session **sess_out) {
    const UserRecord *ur = session_find_user(G.sess_tbl, username);
    if (ur == NULL) {
        net_send_response(client_fd, RES_ERROR, "ERROR: user not found");
        return -1;
    }

    int sess_idx;
    if (session_open(G.sess_tbl, username, getpid(), &sess_idx) < 0) {
        net_send_response(client_fd, RES_ERROR,
                          "ERROR: cannot open session");
        return -1;
    }

    *sess_idx_out = sess_idx;
    *sess_out     = &G.sess_tbl->sessions[sess_idx];

    transfer_worker_init(G.tr_tbl, username, client_fd);

    char msg[MAX_USERNAME + 32];
    snprintf(msg, sizeof(msg), "OK Logged in as '%s'", username);
    net_send_response(client_fd, RES_OK, msg);
    log_info("User '%s' logged in (pid=%d)", username, (int)getpid());

    transfer_check_pending(G.tr_tbl, username, client_fd);
    return 0;
}
